## Ex1-1. Find nearst
数値のイテラブル`iterable`と，数値`key`を取って，`iterable`の中から`key`と一番近い値を返す関数`find_nearest(iterable, key)`を定義せよ．