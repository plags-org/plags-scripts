import sys
sys.path.append('.judge')
import judge_util # モジュール全体をそのままの名前でimport

# この名前は任意
Hidden = judge_util.testcase(score=1)

@judge_util.test_method(Hidden)
def h0(self):
    self.assertEqual(find_nearest(range(10), 3), 3)

@judge_util.test_method(Hidden)
def h1(self):
    self.assertIn(find_nearest(range(1,20,2), 6), (5,7))
