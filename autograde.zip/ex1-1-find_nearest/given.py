import sys
sys.path.append('.judge')
import judge_util # モジュール全体をそのままの名前でimport

# この名前は任意
Given = judge_util.testcase(score=1) # 正解時の得点（default: 1）

# 検査対象を実行して出力を比較するテスト
@judge_util.test_method(Given) # 成功時にCOタグ，失敗時にIOタグを付与
def g0(self):
    # 引数のselfはunittest.TestCaseのインスタンス
    self.assertEqual(find_nearest(range(10), 7), 7)

@judge_util.test_method(Given)
def g1(self):
    _find_nearest = judge_util.argument_logger(find_nearest) # 引数のロギング（オプショナル）
    self.assertIn(_find_nearest(range(1,20,2), 4), (3,5))

#NOTE: 
# 引数ロギングは実引数がリテラルに記述されない時に役立つ．
# 自動評価結果のErrorの部分にログが出力される．
