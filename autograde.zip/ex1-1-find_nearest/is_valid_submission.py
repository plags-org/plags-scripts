import sys
sys.path.append('.judge')
import judge_util # モジュール全体をそのままの名前でimport

# この名前は任意
IsValidSubmission = judge_util.testcase(score=1) # 正解時の得点（default: 1）

# precheckは対象関数に対する静的検査
@judge_util.precheck(IsValidSubmission)
def function_exists():
    # assertせずに例外を投げるのでselfを取らない
    find_nearest # 定義されていなければNameError

@judge_util.precheck(IsValidSubmission)
def function_filled():
    judge_util.raise_if_null_function(find_nearest) # ...のみをbodyに持つ関数なら例外を投げる
