## Ex1-2. Find nearst without iteration
数値のイテラブル`iterable`と，数値`key`を取って，`iterable`の中から`key`と一番近い値を返す関数`find_nearest(iterable, key)`を，for文やwhile文による反復を用いずに定義せよ．