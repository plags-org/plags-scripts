import sys
sys.path.append('.judge')
import judge_util # モジュール全体をそのままの名前でimport

# この名前は任意
Precheck = judge_util.testcase(score=1) # 正解時の得点（default: 1）

# テスト対象の定義の有無を検査
@judge_util.name_error_trap(Precheck, 'ND') # NameErrorを捉えてタグ付けする
def function_exists(): # selfを取らない
    find_nearest_str # 定義の有無を調べたい名前を参照（定義が無いときに NameError を起こす）

# 検査対象を実行しない静的検査
@judge_util.check_method(Precheck, 'NF') # 失敗時に付くタグ（オプショナル）
def function_filled(self):               # エラー時にはタグが付かない
    self.assertFalse(judge_util.is_ellipsis_body(find_nearest_str)) # ...のみをbodyに持つなら失敗 

# 得点に影響しないタグ付け
@judge_util.check_method(Precheck)
def question_exists(self):
    try:
        QUESTION_EXISTS
    except NameError:
        pass
    else:
        if QUESTION_EXISTS:
            judge_util.set_ok_tag(self, 'QE')

judge_util.unittest_main()
