import sys
sys.path.append('.judge')
import judge_util # モジュール全体をそのままの名前でimport

# この名前は任意
Precheck = judge_util.testcase(score=1) # 正解時の得点（default: 1）

# 検査対象を実行しない静的検査
@judge_util.check_method(Precheck)
def function_exists(self):
    # 引数のselfはunittest.TestCaseのインスタンス
    try:
        find_nearest_str
    except NameError:
        self.fail()

@judge_util.check_method(Precheck, 'NF') # 失敗時に付くタグ（オプショナル）
def function_filled(self):               # エラー時にはタグが付かない
    self.assertFalse(judge_util.is_ellipsis_body(find_nearest_str)) # ...のみをbodyに持つなら失敗 

# 得点に影響しないタグ付け
@judge_util.tagging_method(Precheck, 'QE') # 成功時に付くタグ
def question_exists(self):
    self.assertTrue(QUESTION_EXISTS)
