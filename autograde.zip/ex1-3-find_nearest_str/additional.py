import sys
sys.path.append('.judge')
import judge_util # モジュール全体をそのままの名前でimport

# この名前は任意
Additional = judge_util.testcase(score=1)

@judge_util.testmethod(Additional)
def A0(self):
    self.assertEqual(find_nearest_str(['a','b'], 'a'), 'a')
    self.assertEqual(find_nearest_str(['a','b'], 'b'), 'b')

@judge_util.testmethod(Additional)
def A1(self):
    self.assertEqual(find_nearest_str(['a'], 'b'), 'a')
    self.assertEqual(find_nearest_str(['b'], 'a'), 'b')
