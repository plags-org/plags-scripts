import sys
sys.path.append('.judge')
import judge_util # モジュール全体をそのままの名前でimport

# この名前は任意
Hidden = judge_util.testcase(score=1)

@judge_util.test_method(Hidden)
def h0(self):
    self.assertEqual(find_nearest_str(['a','b'], 'a'), 'a')
    self.assertEqual(find_nearest_str(['a','b'], 'b'), 'b')

@judge_util.test_method(Hidden)
def h1(self):
    self.assertEqual(find_nearest_str(['a'], 'b'), 'a')
    self.assertEqual(find_nearest_str(['b'], 'a'), 'b')

judge_util.unittest_main()
